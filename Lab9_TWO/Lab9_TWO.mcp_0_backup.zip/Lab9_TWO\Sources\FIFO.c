/* #include "FIFO.h"

extern unsigned char Buffer[4];
unsigned char Data;
unsigned char WriteInd = 0;
unsigned char ReadInd = 0;

void FIFO_Put(unsigned char);
void FIFO_Init(void);
unsigned char FIFO_Get(void);

int main(void){

}

void FIFO_Put(unsigned char input){
   Buffer[WriteInd] = input;
   WriteInd++;          
}

unsigned char FIFO_Get(){
  Data = Buffer[ReadInd];
  ReadInd++;
  return Data; 
}    */