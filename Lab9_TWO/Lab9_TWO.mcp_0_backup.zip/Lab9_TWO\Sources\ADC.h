//ADC Header File
//*************** ADC_Init ***************
//Inputs: 
void ADC_Init(void);
unsigned short ADC_In(unsigned short);