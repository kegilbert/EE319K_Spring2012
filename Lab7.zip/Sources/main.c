#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */
#include "PLL.h"       
#include "DAC.h" 

unsigned char Data; // 0 to 15 DAC output 

void main(void) {

  PLL_Init();   // Engaging PLL allows use to run 9S12 at 24MHz even in RUN mode
  DAC_Init(); 
  EnableInterrupts;
  Data = 0; 
  for(;;) {
    DAC_Out(Data); 
    Data = 0x0F&(Data+1);  
  }
}
