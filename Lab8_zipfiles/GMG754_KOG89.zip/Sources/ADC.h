void ADC_Init(void);
unsigned short ADC_In(unsigned short channel);
