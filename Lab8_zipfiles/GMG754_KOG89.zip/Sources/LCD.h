void LCD_Open(void);
void LCD_GoTo(unsigned short position);
void LCD_Clear(void);
void LCD_OutDec(unsigned short number);
void LCD_OutString(char *pt);
void LCD_OutFix(unsigned short integerPart);
void Timer_Wait10ms(unsigned short time);

