#include "derivative.h"

void Piano_Init(void) {
    PTP = PTP & 0xF8;   // PP0,1,2 inputs (0)
}


unsigned char Piano_In(void) {
     unsigned char PTPmask;
     unsigned char cmp = 7;    // Determine switch values
     signed char i;      // Loop counter
     
     PTPmask = (PTP&=0x07);
     
     for(i=7;i>=0;i--) {
        if(PTPmask == i) {
        break; 
        } else {
            /* Do Nothing, return to loop */
        }
     }
        /* Pass back A,G,F (1,2,4) depending on what button pressed, sound files will 
           use to branch to correct note */ 
         return i;
}
    