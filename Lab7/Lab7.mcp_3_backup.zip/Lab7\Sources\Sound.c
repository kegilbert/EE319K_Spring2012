#include "derivative.h" 
unsigned int PERIOD;
unsigned char count;
const unsigned char sinewave[32];
void Sound_Init(void) {
    const unsigned char sinewave[32] = {
       8,9,11,12,13,14,14,15,15,15,14,14,13,12,11,9,8,7,5,4,3,
       2,2,1,1,1,2,2,3,4,5,7 
    }; // Array of output values to DAC, forms sine wave   
     
    asm sei
    TSCR1 = 0x80;
    TSCR2 = 0x03;  // TCNT enabled to 1 microseconds (PLL = 8MHz)  
    TIOS |= 0x40;
    TIE |= 0x40;
    TFLG1 = 0x40;
    asm cli
    
    count = 0;
}


void Sound_Play(unsigned char Note) {
    /* When does this fxn return to main to toggle heartbeat? */
    //unsigned char i;
    
  /* Tests if only 1 switch is pressed, and whether to play A,G, or F */  
    if(Note == 1) {
       /* TODO: set freq of interrupts to 2.27ms/32(A note) */
       PERIOD = 71; //(TCNT+71) = 71 microseconds int*32=2.27ms Period    
    }
    if(Note == 2) {
       /* TODO: Set freq of interrupts to Xms/32(G) */
       PERIOD = 80; //80 microsecond int*32 = 2.56ms Period
    }  
    if(Note == 4) {
        /* TODO: Set freq of interrupts to Xms/32(F) */
       PERIOD = 90; //90 microsecond int*32 =~ 2.89ms Period 
    }  else {
          return;
       }
          
   while(PTP == Note) {
      TC6 = TCNT + PERIOD;
      TFLG1 = 0x40;
   }
} 

interrupt 14 void OC6handler(void) {
      DAC_Out(sinewave[count]); 
      count = (++count)%32; 
}  