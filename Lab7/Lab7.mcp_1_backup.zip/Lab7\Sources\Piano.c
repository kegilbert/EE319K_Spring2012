#include "derivative.h"

void Piano_Init(void) {
    PTP = PTP & 0xF8;   // PP0,1,2 inputs (0)
}


unsigned char Piano_In(void) {
     /* TODO */
}
    