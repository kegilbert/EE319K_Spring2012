// Interrrupt declaration

void OC0_Init(void);
interrupt 8 void OC0handler(void); 