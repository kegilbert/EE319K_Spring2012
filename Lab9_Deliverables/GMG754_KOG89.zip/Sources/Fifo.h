//Fifo.h
void Fifo_Init(void);
int Fifo_Put(char data);
int Fifo_Get(char *dataPt);